let ortSession = null;
const videoElement = document.getElementById('webcam');
const videoUpload = document.getElementById('video-upload');
const canvas = document.getElementById('canvas-output');
const ctx = canvas.getContext('2d');

let activeMedia = videoElement;
let forwardCount = 0;
let backwardCount = 0;
let totalPigCounted = 0;
let isFlipped = false;
let trackHistory = {};

setInterval(() => {
    const now = new Date();
    document.getElementById('clock').innerText = `🕒 ${now.toLocaleTimeString('vi-VN')}  |  📅 ${now.toLocaleDateString('vi-VN')}`;
}, 1000);

async function loadModel() {
    try {
        document.getElementById('status-msg').innerText = "Đang nạp weights1.onnx vào trình duyệt...";
        ort.env.wasm.wasmPaths = "https://cdn.jsdelivr.net/npm/onnxruntime-web/dist/";
        ortSession = await ort.InferenceSession.create('./weights1.onnx', { executionProviders: ['wasm'] });
        document.getElementById('status-msg').innerText = "Mô hình AI & LineZone đã sẵn sàng hoạt động!";
    } catch (e) {
        console.error("Lỗi nạp mô hình:", e);
        document.getElementById('status-msg').innerText = "Lỗi nạp weights1.onnx. Kiểm tra lại file!";
    }
}
loadModel();

async function startWebcam() {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 }, audio: false });
        videoElement.srcObject = stream;
        await videoElement.play();
        activeMedia = videoElement;
        requestAnimationFrame(processVideoFrame);
        document.getElementById('status-msg').innerText = "Đang chạy luồng Camera trực tiếp...";
    } catch (err) {
        alert("Không thể mở camera: " + err.message);
    }
}

function loadVideoFile(event) {
    const file = event.target.files[0];
    if (file) {
        const fileURL = URL.createObjectURL(file);
        videoUpload.src = fileURL;
        videoUpload.play();
        activeMedia = videoUpload;
        requestAnimationFrame(processVideoFrame);
        document.getElementById('status-msg').innerText = "Đang chạy video mô phỏng...";
    }
}

async function processVideoFrame() {
    if (activeMedia.paused || activeMedia.ended) {
        requestAnimationFrame(processVideoFrame);
        return;
    }

    canvas.width = 640;
    canvas.height = 480;
    ctx.drawImage(activeMedia, 0, 0, canvas.width, canvas.height);

    if (ortSession) {
        try {
            const inputTensor = preprocessImage(canvas);
            const results = await ortSession.run({ images: inputTensor });
            const output = results[Object.keys(results)[0]].data;
            drawDetectionsAndLineZone(output, canvas.width, canvas.height);
        } catch (err) {
            console.error("Lỗi suy luận AI:", err);
        }
    }

    requestAnimationFrame(processVideoFrame);
}

function preprocessImage(targetCanvas) {
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = 640;
    tempCanvas.height = 640;
    const tempCtx = tempCanvas.getContext('2d');
    tempCtx.drawImage(targetCanvas, 0, 0, 640, 640);

    const imgData = tempCtx.getImageData(0, 0, 640, 640);
    const data = imgData.data;
    const input = new Float32Array(3 * 640 * 640);

    for (let i = 0; i < data.length / 4; i++) {
        input[i] = data[i * 4] / 255.0;
        input[i + 640 * 640] = data[i * 4 + 1] / 255.0;
        input[i + 2 * 640 * 640] = data[i * 4 + 2] / 255.0;
    }
    return new ort.Tensor('float32', input, [1, 3, 640, 640]);
}

function drawDetectionsAndLineZone(outputData, width, height) {
    const lineY = height * 0.60;
    const colorChuaDem = '#00ffff';
    const colorDaDem = '#00ff00';

    ctx.lineWidth = 3;
    ctx.strokeStyle = colorDaDem;
    ctx.beginPath();
    ctx.moveTo(20, lineY);
    ctx.lineTo(width - 20, lineY);
    ctx.stroke();

    ctx.fillStyle = colorChuaDem;
    ctx.beginPath(); ctx.arc(20, lineY, 5, 0, 2 * Math.PI); ctx.fill();
    ctx.beginPath(); ctx.arc(width - 20, lineY, 5, 0, 2 * Math.PI); ctx.fill();

    ctx.font = 'bold 13px Arial';
    ctx.fillStyle = colorChuaDem;
    ctx.fillText("CHUA DEM", 20, lineY - 12);
    ctx.fillStyle = colorDaDem;
    ctx.fillText("DA DEM", 20, lineY + 24);

    document.getElementById('so_heo').innerText = totalPigCounted;
    document.getElementById('detail').innerText = `Từ IN qua OUT (+): ${forwardCount}  |  Quay ngược (-): ${backwardCount}`;
}

function resetCounter() {
    forwardCount = 0;
    backwardCount = 0;
    totalPigCounted = 0;
    trackHistory = {};
    document.getElementById('inp_trai').value = "";
    document.getElementById('inp_loaiheo').value = "";
    document.getElementById('inp_bienso').value = "";
    document.getElementById('inp_sanso').value = "";
}

function flipDirection() {
    isFlipped = !isFlipped;
    resetCounter();
    alert("Đã thay đổi chiều đếm thành công!");
}